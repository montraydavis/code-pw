
# Comprehensive Guide to Converting Selenium to Playwright in C#

## 2. Finding Elements

### Find by ID

**Selenium:**
```csharp
driver.FindElement(By.Id("id"));
```

**Playwright:**
```csharp
page.Locator("#id");
```

**Conversion Steps:**
1. Search for `driver.FindElement(By.Id("id"))`.
2. Replace with Playwright locator code.

**Manual Replace:**
```csharp
// Replace this
driver.FindElement(By.Id("id"));

// With this
page.Locator("#id");
```

**Regex Replace:**
- Search: `driver.FindElement\(By.Id\("([^"]+)"\)\)`
- Replace: `page.Locator("#$1")`
