
# Comprehensive Guide to Converting Selenium to Playwright in C#

## 10. Screenshots

### Take Screenshot

**Selenium:**
```csharp
((ITakesScreenshot)driver).GetScreenshot().SaveAsFile("screenshot.png");
```

**Playwright:**
```csharp
await page.ScreenshotAsync(new PageScreenshotOptions { Path = "screenshot.png" });
```

**Conversion Steps:**
1. Search for `((ITakesScreenshot)driver).GetScreenshot().SaveAsFile("screenshot.png")`.
2. Replace with Playwright screenshot code.

**Manual Replace:**
```csharp
// Replace this
((ITakesScreenshot)driver).GetScreenshot().SaveAsFile("screenshot.png");

// With this
await page.ScreenshotAsync(new PageScreenshotOptions { Path = "screenshot.png" });
```

**Regex Replace:**
- Search: `\(\(ITakesScreenshot\)driver\).GetScreenshot\(\).SaveAsFile\("([^"]+)"\);`
- Replace: `await page.ScreenshotAsync(new PageScreenshotOptions { Path = "$1" });`
