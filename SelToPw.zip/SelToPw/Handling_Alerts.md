
# Comprehensive Guide to Converting Selenium to Playwright in C#

## 6. Handling Alerts

### Accept Alert

**Selenium:**
```csharp
driver.SwitchTo().Alert().Accept();
```

**Playwright:**
```csharp
page.Dialog += async (_, dialog) => await dialog.AcceptAsync();
```

**Conversion Steps:**
1. Search for `driver.SwitchTo().Alert().Accept()`.
2. Replace with Playwright alert accept code.

**Manual Replace:**
```csharp
// Replace this
driver.SwitchTo().Alert().Accept();

// With this
page.Dialog += async (_, dialog) => await dialog.AcceptAsync();
```

**Regex Replace:**
- Search: `driver.SwitchTo\(\).Alert\(\).Accept\(\);`
- Replace: `page.Dialog += async (_, dialog) => await dialog.AcceptAsync();`
