
# Comprehensive Guide to Converting Selenium to Playwright in C#

## 5. Waiting for Elements

### Explicit Wait

**Selenium:**
```csharp
WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
IWebElement element = wait.Until(d => d.FindElement(By.Id("elementId")));
```

**Playwright:**
```csharp
await page.WaitForSelectorAsync("#elementId");
var element = page.Locator("#elementId");
```

**Conversion Steps:**
1. Search for `WebDriverWait` and `wait.Until`.
2. Replace with Playwright wait code.

**Manual Replace:**
```csharp
// Replace this
WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
IWebElement element = wait.Until(d => d.FindElement(By.Id("elementId")));

// With this
await page.WaitForSelectorAsync("#elementId");
var element = page.Locator("#elementId");
```

**Regex Replace:**
- Search: `WebDriverWait wait = new WebDriverWait\(([^)]+)\);\s+IWebElement element = wait.Until\(d => d.FindElement\(By.Id\("([^"]+)"\)\)\);`
- Replace: `await page.WaitForSelectorAsync("#$2");\nvar element = page.Locator("#$2");`
