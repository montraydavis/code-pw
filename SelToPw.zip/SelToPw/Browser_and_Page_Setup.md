
# Comprehensive Guide to Converting Selenium to Playwright in C#

## 1. Browser and Page Setup

### Launch Browser

**Selenium:**
```csharp
IWebDriver driver = new ChromeDriver();
```

**Playwright:**
```csharp
var playwright = await Playwright.CreateAsync();
var browser = await playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions { Headless = false });
```

**Conversion Steps:**
1. Search for `new ChromeDriver()`.
2. Replace with Playwright initialization code.
   
**Manual Replace:**
```csharp
// Replace this
IWebDriver driver = new ChromeDriver();

// With this
var playwright = await Playwright.CreateAsync();
var browser = await playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions { Headless = false });
```

**Regex Replace:**
- Search: `new ChromeDriver\(\)`
- Replace: `var playwright = await Playwright.CreateAsync();\nvar browser = await playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions { Headless = false });`

### Open New Page

**Selenium:**
```csharp
driver.Navigate().GoToUrl(url);
```

**Playwright:**
```csharp
var page = await browser.NewPageAsync();
await page.GotoAsync(url);
```

**Conversion Steps:**
1. Search for `driver.Navigate().GoToUrl(url)`.
2. Replace with Playwright page navigation code.

**Manual Replace:**
```csharp
// Replace this
driver.Navigate().GoToUrl(url);

// With this
var page = await browser.NewPageAsync();
await page.GotoAsync(url);
```

**Regex Replace:**
- Search: `driver.Navigate\(\).GoToUrl\(([^)]+)\);`
- Replace: `var page = await browser.NewPageAsync();\nawait page.GotoAsync($1);`

### Close Browser

**Selenium:**
```csharp
driver.Quit();
```

**Playwright:**
```csharp
await browser.CloseAsync();
```

**Conversion Steps:**
1. Search for `driver.Quit()`.
2. Replace with Playwright browser close code.

**Manual Replace:**
```csharp
// Replace this
driver.Quit();

// With this
await browser.CloseAsync();
```

**Regex Replace:**
- Search: `driver.Quit\(\);`
- Replace: `await browser.CloseAsync();`
