
# Comprehensive Guide to Converting Selenium to Playwright in C#

## 7. Frames

### Switch to Frame

**Selenium:**
```csharp
driver.SwitchTo().Frame(frameElement);
```

**Playwright:**
```csharp
var frame = page.Frame("frameName");
```

**Conversion Steps:**
1. Search for `driver.SwitchTo().Frame`.
2. Replace with Playwright frame switch code.

**Manual Replace:**
```csharp
// Replace this
driver.SwitchTo().Frame(frameElement);

// With this
var frame = page.Frame("frameName");
```

**Regex Replace:**
- Search: `driver.SwitchTo\(\).Frame\(([^)]+)\);`
- Replace: `var frame = page.Frame("$1");`
