
# Comprehensive Guide to Converting Selenium to Playwright in C#

## 9. Keyboard and Mouse Actions

### Send Keys

**Selenium:**
```csharp
element.SendKeys("text");
```

**Playwright:**
```csharp
await page.Keyboard.TypeAsync("text");
```

**Conversion Steps:**
1. Search for `element.SendKeys("text")`.
2. Replace with Playwright send keys code.

**Manual Replace:**
```csharp
// Replace this
element.SendKeys("text");

// With this
await page.Keyboard.TypeAsync("text");
```

**Regex Replace:**
- Search: `(\w+)\.SendKeys\("([^"]+)"\);`
- Replace: `await page.Keyboard.TypeAsync("$2");`
