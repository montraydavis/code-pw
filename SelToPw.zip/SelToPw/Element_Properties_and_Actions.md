
# Comprehensive Guide to Converting Selenium to Playwright in C#

## 4. Element Properties and Actions

### Get Text

**Selenium:**
```csharp
string text = element.Text;
```

**Playwright:**
```csharp
string text = await element.TextContentAsync();
```

**Conversion Steps:**
1. Search for `element.Text`.
2. Replace with Playwright get text code.

**Manual Replace:**
```csharp
// Replace this
string text = element.Text;

// With this
string text = await element.TextContentAsync();
```

**Regex Replace:**
- Search: `(\w+)\.Text`
- Replace: `await $1.TextContentAsync()`
