
# Comprehensive Guide to Converting Selenium to Playwright in C#

## 8. Handling Windows and Tabs

### Switch to Window

**Selenium:**
```csharp
driver.SwitchTo().Window(windowHandle);
```

**Playwright:**
```csharp
var page = await context.NewPageAsync();
```

**Conversion Steps:**
1. Search for `driver.SwitchTo().Window`.
2. Replace with Playwright window switch code.

**Manual Replace:**
```csharp
// Replace this
driver.SwitchTo().Window(windowHandle);

// With this
var page = await context.NewPageAsync();
```

**Regex Replace:**
- Search: `driver.SwitchTo\(\).Window\(([^)]+)\);`
- Replace: `var page = await context.NewPageAsync();`
